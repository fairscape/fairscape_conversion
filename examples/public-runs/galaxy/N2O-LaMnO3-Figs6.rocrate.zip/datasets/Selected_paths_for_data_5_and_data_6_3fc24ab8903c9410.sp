  id,                 filename,                    label, degen, s02,   e0,                   sigma2,     deltar
   1,        feff/feff0001.dat,                   O.Mn.1, degen, s02,   e0,              sigma2_omn1, alpha_omn1*reff
   2,        feff/feff0002.dat,                 O.O.Mn.2, degen, s02,   e0,             sigma2_oomn2, alpha_oomn2*reff
   3,        feff/feff0003.dat,                  La.Mn.3, degen, s02,   e0,             sigma2_lamn3, alpha_lamn3*reff
