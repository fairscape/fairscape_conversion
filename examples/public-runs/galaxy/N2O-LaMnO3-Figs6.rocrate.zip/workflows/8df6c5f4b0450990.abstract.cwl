class: Workflow
label: Paper 9 N2O-LaMnO3 Figs6
cwlVersion: v1.2
inputs:
  Figure_6_7A_B_XAFS.prj:
    id: Figure_6_7A_B_XAFS.prj
    type: File
  1697445.cif:
    id: 1697445.cif
    type: File
outputs: {}
steps:
  '2':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      merge_inputs|format|dat_file:
        source: Figure_6_7A_B_XAFS.prj
    out: []
  '3':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      format|structure_file:
        source: 1697445.cif
    out: []
  '4':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      input:
        source: 2/athena_project_file_collection
    out:
    - output
  '5':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      input:
        source: 2/athena_project_file_collection
    out:
    - output
  '6':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      input:
        source: 2/athena_project_file_collection
    out:
    - output
  '7':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      feff_outputs_0|paths_file:
        source: 3/out_csv
      feff_outputs_0|paths_zip:
        source: 3/out_dir
    out: []
  '8':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      sp_file:
        source: 7/sp_csv
      gds_file:
        source: 7/gds_csv
      execution|format|prj_file:
        source: '4'
      feff_paths:
        source: 3/out_dir
    out: []
  '9':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      sp_file:
        source: 7/sp_csv
      gds_file:
        source: 7/gds_csv
      execution|format|prj_file:
        source: '5'
      feff_paths:
        source: 3/out_dir
    out: []
  '10':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      sp_file:
        source: 7/sp_csv
      gds_file:
        source: 7/gds_csv
      execution|format|prj_file:
        source: '6'
      feff_paths:
        source: 3/out_dir
    out: []
