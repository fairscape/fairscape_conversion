  id,                 filename,                    label, s02,   e0,                   sigma2,     deltar
   1,        feff/feff0001.dat,                   S.Fe.1, s02,   e0,              sigma2_sfe1, alpha*reff
   2,        feff/feff0002.dat,                   S.Fe.2, s02,   e0,              sigma2_sfe2, alpha*reff
   3,        feff/feff0003.dat,                  Fe.Fe.3, s02,   e0,             sigma2_fefe3, alpha*reff
