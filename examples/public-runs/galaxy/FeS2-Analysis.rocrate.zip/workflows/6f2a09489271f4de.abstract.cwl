class: Workflow
doc: Same as the basic example from Demeter training
label: FeS2 Analysis
cwlVersion: v1.2
inputs:
  fes2_rt01_mar02.xmu:
    id: fes2_rt01_mar02.xmu
    type: File
  1564889.cif:
    id: 1564889.cif
    type: File
outputs:
  FeS2_plot:
    outputSource: 2/plot
    type: File
  FeS2_athena:
    outputSource: 2/athena_project_file
    type: File
  fes2_sp.csv:
    outputSource: 4/sp_csv
    type: File
  fes2_gds.csv:
    outputSource: 4/gds_csv
    type: File
  fit_report_FeS2:
    outputSource: 5/fit_report
    type: File
  rmr_FeS2:
    outputSource: 5/rmr
    type: File
  chikr_FeS2:
    outputSource: 5/chikr
    type: File
steps:
  '2':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      merge_inputs|format|is_zipped|dat_file:
        source: fes2_rt01_mar02.xmu
    out:
    - athena_project_file
    - plot
  '3':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      format|structure_file:
        source: 1564889.cif
    out: []
  '4':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      feff_outputs_0|paths_zip:
        source: 3/out_dir
      feff_outputs_0|paths_file:
        source: 3/out_csv
    out:
    - gds_csv
    - sp_csv
  '5':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      gds_file:
        source: 4/gds_csv
      sp_file:
        source: 4/sp_csv
      feff_paths:
        source: 3/out_dir
      execution|prj_file:
        source: 2/athena_project_file
    out:
    - rmr
    - chikr
    - fit_report
